ssh_username_wait = 0
urlscan_wait = 0
brute_wait = 0
portscan_wait = 0
subdomain_wait = 0
slowhttp_wait = 0