# AntCode
Linux/Mac下的代碼審計工具

# 截圖
![](https://i.loli.net/2021/08/09/LeKmdP9WrI6iV7b.jpg)

# 使用教程
```
python3 antcode.py <dir>

#example:
python3 antcode.py ./
```

# 自定義規則
修改rule文件夾中的文件即可。

