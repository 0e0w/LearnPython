checkExt = {
    "php":["php","html","tpl","phtml","php3"],
    "python":["py"],
    "go":["go"],
    "shell":["sh"]
}