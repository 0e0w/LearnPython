#!/usr/bin/env python3
# -*- coding=utf-8 -*-

import totalpwd


def test_main():
    assert totalpwd.main() == "TotalPwd"
