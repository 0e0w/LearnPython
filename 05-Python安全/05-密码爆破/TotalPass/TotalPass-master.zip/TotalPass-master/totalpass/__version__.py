#!/usr/bin/env python3
# -*- coding=utf-8 -*-


__title__ = "TotalPass"
__description__ = "Defualt password scanner and searcher"
__url__ = "https://github.com/0xHJK/TotalPass"
__version__ = "0.0.2"
__author__ = "HJK"
__author_email__ = "HJKdev@gmail.com"
__license__ = "MIT License"
__copyright__ = "Copyright 2020 HJK"
