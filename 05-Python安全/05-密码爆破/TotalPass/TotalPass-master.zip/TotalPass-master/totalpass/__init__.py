#!/usr/bin/env python3
# -*- coding=utf-8 -*-


from .__version__ import __version__
from .__main__ import main
