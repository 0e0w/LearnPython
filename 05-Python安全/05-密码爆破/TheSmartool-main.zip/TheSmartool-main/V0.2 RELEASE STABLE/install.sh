#!/bin/bash
sudo apt install python-pip 
sudo apt install python3-pip
pip install requests
python3 install.py