#!/bin/bash

sudo apt-get update -y
echo "Succes"
sudo apt-get install pip -y
echo "Succes"
sudo apt-get install pip3 -y
echo "Succes"
pip install whois
echo "Succes"
pip3 install requests
echo "Succes"
pip install time
echo "Succes"
pip install pythonpip
echo "Succes"
pip install bs4 requests 
echo "Succes"
pip install nltk
echo "Succes"
pip install htmlparser
echo "Succes"
pip install lxml
echo "Succes"
pip install rarfile
echo "Succes"
pip install pythongping
echo "Succes"
pip install termcolor
echo "Succes"
pip install paramiko
echo "Succes"
pip install spur
echo "Succes"
pip install proxy-checker
echo "Succes"
pip install getmac
echo "Succes"
pip install getmac
echo "Succes"
clear
echo "Good, you can run now the script with \"sudo python3 smartool.py\""
