# TheSmartool


**The Smartool tool is a hacking script developed by me, your hacking courses will be easier ! 🦩**
**All this in python!  🩸**


***Education only ! Do not missue this tool***

*All the tools who are used (ftp cracker, ssh cracker etc...) were written by me except Metasploit obviously.*

**How to install !**

Working perfectly on Kali Linux, if you try to run it on other Linux distrib, you may met some bug.

```
(sudo) apt-get update
sudo apt install python-pip
sudo apt install python3-pip 
git clone https://github.com/Coroxx/TheSmartool
cd TheSmartool
sudo chmod +x install.sh
bash install.sh
sudo python3 smartool.py
```


![alt text](https://i.ibb.co/8j2mQQc/image-2021-01-01-012214.png)

**This project is currently on a Beta 🐉 version, it includes an update checker, when you launch it you get this message :**

![alt text](https://i.ibb.co/k627czx/image-2020-12-21-143256.pngg)

*And when you need to update it :*

![alt text](https://i.ibb.co/FsNd3MQ/image-2020-12-21-144059.png)


**🏺 Some useful features like 🏺 :** 

- SSH Password Bruteforcer 
- FTP Password Bruteforcer
- FreshProxyDownloader
- ProxyChecker
- AdminPageFinder

*Password menu :*

![alt text](https://i.ibb.co/Pj0fN3k/image-2020-12-21-144457.png)


*Admin Page Finder :* 

![alt text](https://i.ibb.co/W3Tq3tz/image-2021-01-01-013528.png) 
```
Find fast the potential admin login page of a website !
```

*Proxy Downloader :*

![alt text](https://i.ibb.co/41c5HQh/image-2021-01-01-013008.png)
```
Download easily the last proxy from the web
```

*Proxy Checker :* 

![alt text](https://i.ibb.co/q5GjBgP/image-2021-01-01-013230.png) 
```
Keep the fast and alive proxy and make a clean proxy list ! 
```

*FTP BruteForcer :* 
![alt text](https://i.ibb.co/qJ9GsP7/image-2021-01-07-100003.png)
```
Bruteforcer for FTP servers
```

*SSH BruteForcer :* 
![alt text](https://i.ibb.co/sWyCKGq/image-2021-01-07-100225.png)
```
Bruteforcer for SSH session password
```


*A lot of new features are coming soon ⏰ !* 
*Do not hesitate to make a new issue when you discover a bug, I would be glad to patch it :D
Contact : Corox#0666*
