#!/bin/bash
sudo apt install python-pip 
sudo apt install python3-pip
sudo apt install telnet -y 
pip install requests
python3 install.py