
class ColorShock:
    def __new__(cls):
        return  {
            'end': '\033[0m',
            'white': '\33[37m',
            'white2': '\33[97m',
            'black': '\033[30m',
            'red': '\033[31m',
            'green': '\033[32m',
            'orange': '\033[33m',
            'blue': '\033[34m',
            'purple': '\033[35m',
            'cyan': '\033[36m',
            'pink': '\033[95m',
            'yellow': '\033[93m',
            'light_grey': '\033[37m',
            'dark_grey': '\033[90m',
            'light_red': '\033[91m',
            'light_green': '\033[92m',
            'light_blue': '\033[94m',
            'light_cyan': '\033[96m',
        }
