import logging

class DebugShock:

    def debug(self):
        return logging.basicConfig(level=logging.DEBUG)
