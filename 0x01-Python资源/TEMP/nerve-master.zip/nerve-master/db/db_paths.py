
COMMON_WEB_PATHS = [
                 '/', '/pub', '/share', '/uploads', '/files', '/docs', 
                 '/downloads', '/upload', '/uploads', '/export', '/doc', '/conf', '/config', 
                 '/temp', '/tmp', '/db', '/database', '/src', '/source', '/lib', '/root', '/log','/logs',
                 '/shares', '/exports', '/client', '/clients', '/exports', '/test', '/tests', '/databases',
                 '/webcgi/', '/bin', '/cgi', '/cgi-bin',  '/cgis', '/scripts', '/members', '/private', '/media',
                 '/documents', '/backup', '/backups', '/data'
                 ]

COMMON_LOGIN_PATHS = ['/', '/login', '/remote/login', '/admin', '/administrator', '/panel', '/dashboard', '/adm', '/members', '/private', '/manager']

COMMON_CGI_PATHS = ['/cgi-bin/status', '/cgi-bin', '/cgi-bin/php', '/cgi-bin/php5', '/cgi-bin/php4']