# Security Policy

## Reporting a Vulnerability

You may report issues via the Paytm Bug Bounty page https://bugbounty.paytm.com (we do not credit for NERVE related reports) or via GitHub.
