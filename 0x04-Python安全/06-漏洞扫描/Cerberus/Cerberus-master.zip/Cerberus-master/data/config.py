User_agents = \
    [
     "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50",
     "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50",
     "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1",
     "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11"
    ]

Referer = ["https://www,baidu.com","https://www.google.com"]

origin_proxies = {
                  'data5u' : "http://www.data5u.com",
                  'xicidaili' : "https://www.xicidaili.com",
                  # 'goubanjia' : "http://www.goubanjia.com",
                  'ip3366' : "http://www.ip3366.net",
                  'iphai' : "http://www.iphai.com",
                  'cn-proxy' : "https://cn-proxy.com",
                  'ip_jiangxianli' : "http://ip.jiangxianli.com",
                  'xiladaili' : "http://www.xiladaili.com",
                  'ip_ihuan' : "https://ip.ihuan.me"
                 }


