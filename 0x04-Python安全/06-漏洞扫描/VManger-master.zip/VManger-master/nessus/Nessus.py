from Config import Config

class Nessus():
    def __init__(self):
        pass

