class scan():
    def __init__(self):
        pass