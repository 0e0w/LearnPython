---
name: "\U0001F4C3 Documentation request"
about: Suggest additions or fixes to our documentation hub!
title: ''
labels: Documentation
assignees: ''

---

## Documentation request

<!-- Choose: adding a new page, or edit existing content. -->

### Add a new page 🆕

**What documentation you'd like us to add?**
Put suggestion here.

**Where in the documentation tree?**
Put section here.

### Edit existing content 📝

**Which page(s) do you want us to edit?**
Put link here.

**What do you think should be changed?**
Put requested changes here.
