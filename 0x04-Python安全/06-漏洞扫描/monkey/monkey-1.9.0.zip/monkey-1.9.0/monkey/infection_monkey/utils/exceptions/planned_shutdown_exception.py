class PlannedShutdownException(Exception):
    pass
