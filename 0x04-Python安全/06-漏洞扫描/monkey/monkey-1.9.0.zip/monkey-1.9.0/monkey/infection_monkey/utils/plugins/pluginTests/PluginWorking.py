from infection_monkey.utils.plugins.pluginTests.PluginTestClass import \
    TestPlugin


class PluginWorking(TestPlugin):
    pass
