class Exporter(object):
    def __init__(self):
        pass

    @staticmethod
    def handle_report(report_json):
        raise NotImplementedError
