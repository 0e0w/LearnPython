"""This file will include consts values regarding the groupsandusers collection"""

__author__ = 'maor.rayzin'

USERTYPE = 1
GROUPTYPE = 2
