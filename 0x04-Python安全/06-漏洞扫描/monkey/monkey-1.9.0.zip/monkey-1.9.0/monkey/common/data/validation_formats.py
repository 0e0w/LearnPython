# Defined in UI on ValidationFormats.js
IP_RANGE = "ip-range"
IP = "ip"
