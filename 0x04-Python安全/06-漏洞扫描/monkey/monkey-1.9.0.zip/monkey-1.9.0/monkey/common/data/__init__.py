from .zero_trust_consts import populate_mappings

populate_mappings()
