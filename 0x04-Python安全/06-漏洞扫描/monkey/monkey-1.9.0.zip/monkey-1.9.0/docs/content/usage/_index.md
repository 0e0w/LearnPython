+++
title = "Usage"
date = 2020-05-26T20:57:53+03:00
weight = 10
chapter = true
pre = '<i class="fas fa-users-cog"></i> '
+++

# Usage

If you're just starting with Infection Monkey, check out our [Getting Started](getting-started) page.

If you haven't downloaded Monkey yet, {{% button href="https://www.guardicore.com/infectionmonkey/#download" icon="fas fa-download" %}}Get Infection Monkey here{{% /button %}}!
