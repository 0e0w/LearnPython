---
title: "Configuration"
date: 2020-06-07T19:08:51+03:00
draft: false
chapter: true
weight: 3
pre: "<i class='fas fa-sliders-h'></i> "
---

# Configure the Monkey

The Monkey is highly configurable. Nearly every part of it can be modified to turn it to a fast acting worm or into a port scanning and system information collecting machine.

{{% notice warning %}}
This section of the documentation is incomplete and under active construction.
{{% /notice %}}

See these documentation pages for information on each configuration value:

{{% children description=true %}}
