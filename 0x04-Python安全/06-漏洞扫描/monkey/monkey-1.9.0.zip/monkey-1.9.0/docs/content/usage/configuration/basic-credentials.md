---
title: "Credentials"
date: 2020-06-09T12:20:08+03:00
draft: false
description: "Configure credentials that the Monkey will use for propagation."
---

In this screen you can feed the Monkey with “stolen” credentials for your network, simulating an attacker with inside knowledge.

![Configure credentials](/images/usage/configruation/credentials.png "Configure credentials")
