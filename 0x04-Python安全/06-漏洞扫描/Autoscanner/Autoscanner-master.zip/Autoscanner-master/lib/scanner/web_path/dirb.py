
class dirb():
    def __init__(self):
