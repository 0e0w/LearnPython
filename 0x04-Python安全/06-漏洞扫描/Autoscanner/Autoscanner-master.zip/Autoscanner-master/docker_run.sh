docker run -ti -v `pwd`/:/root/ auto:latest -u http://testphp.vulnweb.com
