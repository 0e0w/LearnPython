#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @author = 'orleven'

from lib.core.datatype import AttribDict
from lib.core.log import logger

paths = AttribDict()

logger = logger()

conf = AttribDict()

