

## PwnServer

#### 🌐️ Language：

[中文](https://github.com/ixiniansec/pwnserver/blob/main/docs/README_ZH.md) 	[English](https://github.com/ixiniansec/pwnserver/blob/main/docs/README_EN.md)


#### 🔗 Connect us! or be one of us!

[TG official group:https://t.me/Pwnserver_devloper](https://t.me/Pwnserver_devloper)


#### Currently supported vulnerability verification:

| CVE-2019-0193 | CVE-2019-17558 | CVE-2018-1723 (manual) | CVE-2019-0708(manual) |
| ------------- | -------------- | ---------------------- | --------------------- |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |
|               |                |                        |                       |

#### 🖼 Screenshot：

![](https://i.imgur.com/Rqdx6ra.png)
