#!/usr/bin/python3
#-*- coding: utf-8 -*-

import os

#PATH
path = os.getcwd()
cache = (path+'/cache')

os.system("tree %s/scripts/poc/"%(path))


