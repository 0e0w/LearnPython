There is the file folder get no use in running,but which is just a floder for developer to know what need to be in if a new POC/EXP folder is created.

This two file is about:
>1) POC_standard file
>
>This is the file to tell how the POC/EXP should use.
>you just need create one command with the example given above.
>
>2) POC_batch_process.py
>
>This is the file,which works as a modules in our pwnserver.
>
>it can auto-create the batch file,according the POC_standard file.
>
>also it give the pre-scanning result ,as IP\port\url, to the batch file. 

this is the secret of the pwnserver when handling the POC/EXP execute file with *different* format
