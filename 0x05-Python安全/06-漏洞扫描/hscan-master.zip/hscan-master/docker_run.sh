docker run -ti --rm -v `pwd`/:/root/ hscan:latest -u testphp.vulnweb.com
