#!/usr/bin/env python
# _*_ coding: utf-8 _*_
from Modules.Apache.Log4j import Log4jRemoteCommandExecutionVulnerability
from ClassCongregation import Prompt

def Main(Pool,**kwargs):
    Pool.Append(Log4jRemoteCommandExecutionVulnerability.medusa,**kwargs)
    Prompt("Log4j")