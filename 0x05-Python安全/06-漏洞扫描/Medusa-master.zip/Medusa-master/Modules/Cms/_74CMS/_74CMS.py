#!/usr/bin/env python
# _*_ coding: utf-8 _*_
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists4
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists5
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists6
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists7
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists8
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists9
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists12
from Modules.Cms._74CMS import _74CMSSQLInjectionVulnerabilityExists14
from ClassCongregation import Prompt
def Main(Pool,**kwargs):
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists4.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists5.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists6.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists7.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists8.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists9.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists12.medusa, **kwargs)
    Pool.Append(_74CMSSQLInjectionVulnerabilityExists14.medusa, **kwargs)
    Prompt("74CMS")