'use strict'
module.exports = {
  NODE_ENV: '"production"',
  servers: {
    // testApi: '"http://47.110.77.140:5000"'
    // testApi: '"http://172.104.66.79:8888"',
    // api: '"/apixxx/"'
    backend: '""',
  }
}
