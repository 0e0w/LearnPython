# /usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File  :   __init.py
@Time  :   2020/12/24 16:36:22
@Author:   Morker
@Blog  :   https://96.mk/
@Email :   i@96.mk

If you don't go through the cold, you can't get the fragrant plum blossom.
'''
