# /usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File  :   __init__.py
@Time  :   2020/12/23 21:33:02
@Author:   Morker
@Blog  :   https://96.mk/
@Email :   i@96.mk

If you don't go through the cold, you can't get the fragrant plum blossom.
'''
