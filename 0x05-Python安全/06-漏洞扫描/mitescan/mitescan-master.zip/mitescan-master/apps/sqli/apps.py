from django.apps import AppConfig


class SqliConfig(AppConfig):
    name = 'apps.sqli'
