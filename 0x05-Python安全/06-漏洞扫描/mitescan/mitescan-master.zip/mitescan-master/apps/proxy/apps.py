from django.apps import AppConfig


class ProxyConfig(AppConfig):
    name = 'apps.proxy'
