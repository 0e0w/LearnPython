from django.apps import AppConfig


class AnyxConfig(AppConfig):
    name = 'apps.anyx'
