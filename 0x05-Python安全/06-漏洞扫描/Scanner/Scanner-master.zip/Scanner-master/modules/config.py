#!/usr/bin/python
# -*- coding:utf8 -*-
#author:Jinhao

# 填写需要全局替换/补充的header头
HEADERS = {

}

# 填写代理
PROXY = {
    'http': '',
    'https': ''
}