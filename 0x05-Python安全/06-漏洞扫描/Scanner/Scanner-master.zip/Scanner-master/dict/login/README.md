包括弱口令字典、目录字典、sql fuzz字典
