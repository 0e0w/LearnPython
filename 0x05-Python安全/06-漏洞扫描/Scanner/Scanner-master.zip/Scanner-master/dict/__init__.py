#!/usr/bin/python
# -*- coding:utf8 -*-
#author:Jinhao

from dict import *

__all__ = ['burp','domain']