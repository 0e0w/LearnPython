from django.apps import AppConfig


class AssetConfig(AppConfig):
    name = 'asset'
    verbose_name = '资产管理'
