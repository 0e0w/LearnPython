from django.apps import AppConfig


class VulnConfig(AppConfig):
    name = 'vuln'
    verbose_name = '漏洞管理'