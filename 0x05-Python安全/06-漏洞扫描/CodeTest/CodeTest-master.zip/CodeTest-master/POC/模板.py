print('''
#代码模板
def check(**kwargs):
	#url = kwargs['url']/*str*/
	#port = kwargs['port']/*str*/
	#
	print('输出结果')
	if True:
		return 1
	else:
		return
''')
import sys
sys.path.append('..')
from CodeTest import CodeTest
def check(**kwargs):
	url = kwargs['url']#/*str*/
	port = kwargs['port']#/*str*/
	print('输出结果')
	print(url)
	print(port)
	if True:
		return 1
	else:
		return


