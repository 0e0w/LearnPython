status         = ""
running_tool   = ""
current_target = ""
report_name    = ""
timings        = {}
sleep_time     = 24
concurrent     = 2
acunetix       = False