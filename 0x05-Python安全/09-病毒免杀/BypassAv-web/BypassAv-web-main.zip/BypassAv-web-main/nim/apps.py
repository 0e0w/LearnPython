from django.apps import AppConfig


class NimConfig(AppConfig):
    name = 'nim'
