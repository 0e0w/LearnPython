## APP 说明

> ZBN SOAR Hello Word

## 动作列表

### HellWord

**参数：**

|  参数   | 类型  |  必填   |  备注  |
|  ----  | ----  |  ----  |  ----  |
| **name**  | string | `是` | 名字 |

**返回值：**

```
Hello {{name}} !"
```