def print_r(color):
    if color == 'white':
        return
    elif color == 'black':
        return
    elif color == 'green':
        return
    elif color == 'blue':
        return
    elif color == 'yellow':
        return
    elif color == 'pink':
        return
    elif color == 'clear':
        return


def console_p(text):
    return text

