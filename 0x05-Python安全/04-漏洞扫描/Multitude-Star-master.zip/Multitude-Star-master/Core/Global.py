class BasicScan:
    pass

class FullScan:
    pass