# Multitude-Star

## 众星Web漏洞扫描器(Multitude Star Web vulnerable scan)

- 主动扫描
- 被动扫描
- 漏洞检测插件化
- 扫描报告导出
- 快捷漏洞验证
