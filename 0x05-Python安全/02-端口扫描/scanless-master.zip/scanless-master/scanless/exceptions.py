"""scanless.exceptions"""


class ScannerNotFound(Exception):
    pass


class ScannerRequestError(Exception):
    pass
