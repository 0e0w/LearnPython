class fakeHeap():
    def __init__(self):
        self.arrayContainer={}