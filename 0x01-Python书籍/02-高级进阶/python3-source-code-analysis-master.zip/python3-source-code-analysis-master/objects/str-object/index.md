# 实现简版 Python
