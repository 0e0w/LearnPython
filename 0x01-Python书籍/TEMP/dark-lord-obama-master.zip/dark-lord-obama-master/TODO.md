1. Fix the command segmentator bug
2. Implement TLS 1.3 and C2 Server
3. Implement ASM executable as C shared object
